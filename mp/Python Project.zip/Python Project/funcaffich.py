import csv
from Classes import *
from tkinter import *
from tkinter import ttk, messagebox
from Functions import *
def RecupereNomFiliere():
    nomfiliere=[]
    for f in ListFiliere:
        nomfiliere.append(f.Nom)
    return nomfiliere
ValideFilier=RecupereNomFiliere()

def AfficheMenu(f):
 
    FM = Frame(f, padx=5, pady=5, bg="#DFDFDF")
    FM.pack()
    lm = Label(FM, text="Menu Principal", font="Tahoma 20", fg="#828282", width=16)
    lm.grid(row=0, column=0, padx=5, pady=5, sticky=NW)
    MP = ["Directeur","formateur", "stagiaire"]
    n = 1
    for i in range(len(MP)):
        BT = Button(FM, text=MP[i], font="Arial 20", fg="#4D4D4D", width=15,
                    command=lambda a=i: Operation(f, FM, MP[a]))
        BT.grid(row=n, column=i % 3, padx=4, pady=4)
        if i % 3 == 2:
            n = n + 1
def MenuDrctr(f,fd):
    
    fd.pack_forget()
    fdr = Frame(f, padx=10, pady=10,bg="#DFDFDF")
    fdr.pack(padx=5, pady=5)
    md = Label(fdr, text="Bienvenue Administrateur", font="Tahoma 20", fg="#828282", width=30)
    md.grid(row=0, column=0, padx=5, pady=5, sticky=NW)



    # Define menu options
    optionsD = [
        "Ajouter une filière",
        "Ajouter un stagiaire",
        "Ajouter un formateur",
        "Afficher la liste des stagiaires",
        "Afficher la liste des formateurs",
        "Supprimer un stagiaire",
        "Supprimer un formateur",
        "Calculer les notes",
        "Enregistrer les notes dans un fichier CSV",
        "Déconnexion"
    ]
    n = 1
    for i in range(len(optionsD)):
        button = Button(fdr, text=optionsD[i], font="Arial 12", fg="#4D4D4D", width=10,
                    command=lambda a=i: OperationD(f, fdr, optionsD[a]))
        button.grid(row=n, column=i % 3 , padx=5, pady=5)
        if i % 3 == 2:
            n = n + 1


def afficherFrameconnexion(f, fd, x):
    global euser, epass
    if x=="stagiaire":
        fd.pack(padx=5, pady=5)
        luser = Label(fd, text="Nom d'utilisateur : ")
        luser.grid(row=0, column=0, padx=5, pady=5, sticky=NW)
        euser = Entry(fd)
        euser.grid(row=0, column=1, padx=5, pady=5, sticky=NW)
        lpass = Label(fd, text="Mot de passe : ")
        lpass.grid(row=1, column=0, padx=5, pady=5, sticky=NW)
        epass = Entry(fd, show="*")
        epass.grid(row=1, column=1, padx=5, pady=5, sticky=NW)
        va = Button(fd, text="loge in", font="Arial 20", fg="#4D4D4D",command=lambda:confirme(f,fd,x))
        va.grid(row=2, column=1, padx=4, pady=4)
        inscrir = Button(fd, text="inscrir", font="Arial 20", fg="#4D4D4D",command=lambda:AjoutStg(f,fd,x))
        inscrir.grid(row=2, column=2, padx=4, pady=4)
       
    else:
        fd = Frame(f, padx=5, pady=5, bg="#DFDFDF")
        fd.pack(padx=5, pady=5)
        luser = Label(fd, text="Nom d'utilisateur : ")
        luser.grid(row=0, column=0, padx=5, pady=5, sticky=NW)
        euser = Entry(fd)
        euser.grid(row=0, column=1, padx=5, pady=5, sticky=NW)
        lpass = Label(fd, text="Mot de passe : ")
        lpass.grid(row=1, column=0, padx=5, pady=5, sticky=NW)
        epass = Entry(fd, show="*")
        epass.grid(row=1, column=1, padx=5, pady=5, sticky=NW)
        va = Button(fd, text="submit", font="Arial 20", fg="#4D4D4D",command=lambda:confirme(f,fd,x))
        va.grid(row=2, column=2, padx=4, pady=4)
def AjoutStg(f,fd,x):
    global Ecode,Enom,Eprenom,Efil,ejoure, emois,eAnnee,enb
    fd.destroy()
    fd=Frame(f,padx=5,pady=5,bg="#AFAFAF")
    fd.pack(padx=5, pady=5) 
    lcode=Label(fd,text="Code :",font="Arial 18",fg="#808080",width=15)
    lcode.grid(row=1,column=0,padx=5,pady=5)
    Ecode=Entry(fd,font="Arial 18",state='normal')
    Ecode.grid(row=1,column=1,padx=5,pady=5)
    lnom=Label(fd,text="Nom :",font="Arial 18",fg="#808080",width=15)
    lnom.grid(row=2,column=0,padx=5,pady=5)
    Enom=Entry(fd,font="Arial 18")
    Enom.grid(row=2,column=1,padx=5,pady=5)
    lprenom=Label(fd,text="Prenom :",font="Arial 18",fg="#808080",width=15)
    lprenom.grid(row=3,column=0,padx=5,pady=5)
    Eprenom=Entry(fd,font="Arial 18")
    Eprenom.grid(row=3,column=1,padx=5,pady=5)
    
    lfil=Label(fd,text="filier :",font="Arial 18",fg="#808080",width=15)
    lfil.grid(row=4,column=0,padx=5,pady=5)
    Efil=ttk.Combobox(fd,width=25,values=ValideFilier,font="Arial 18")
    Efil.grid(row=4,column=1,padx=5,pady=5,sticky=NW)

    lda = Label(fd, text="Date de Naissance:",font="Arial 18",fg="#808080",width=15)
    lda.grid(row=5, column=0,padx=5,pady=5, sticky=W)

    ljoure = Label(fd, text="joure :",font="Arial 18",fg="#808080",width=15)
    ljoure.grid(row=6, column=0,padx=5,pady=5, sticky=W)
    ejoure = Entry(fd)
    ejoure.grid(row=6, column=1, padx=10, pady=5)

    lmois = Label(fd, text="mois :",font="Arial 18",fg="#808080",width=15)
    lmois.grid(row=7, column=0,padx=5,pady=5, sticky=W)
    emois = Entry(fd)
    emois.grid(row=7, column=1, padx=10, pady=5)

    lAnnee = Label(fd, text="Annee :",font="Arial 18",fg="#808080",width=15)
    lAnnee.grid(row=8, column=0,padx=5,pady=5, sticky=W)
    eAnnee = Entry(fd)
    eAnnee.grid(row=8, column=1, padx=10, pady=5)


    lnb = Label(fd, text="Note de Bac:",font="Arial 18",fg="#808080",width=15)
    lnb.grid(row=9, column=0,padx=5,pady=5, sticky=W)
    enb = Entry(fd)
    enb.grid(row=9, column=1, padx=10, pady=5)

    BA=Button(fd,text="Ajouter",font="Arial 18",width=15,command=lambda :AjouterS(f,fd))
    BA.grid(row=10,column=0,padx=5,pady=5) 
         
    BR=Button(fd,text="Menu Principal",font="Tahoma 18",command=lambda :afficherFrameconnexion(f, fd, x))
    BR.grid(row=10,column=2,padx=5,pady=5)


def AjouterS(f,fd):
    if Ecode.get()=="":
        messagebox.showinfo("Attention","Le code est oblégatoire")
    elif ExisteStgr(List_Attend,Ecode.get())==True:
        messagebox.showinfo("Attention","Ce stagaire existe déja")
    else:
        DateNaiS=date(int(ejoure.get()),int(emois.get()),int(eAnnee.get()))
        for f in ListFiliere:
            if f.Nom==Efil.get():
                ListStgr.append(Stagaire(Ecode.get(),f.getid() ,Enom.get(),Eprenom.get(),Efil.get(),DateNaiS,enb.get()))
                messagebox.showinfo("Confirmation","Ce stagaires à bien ajouté")
                fd.destroy()
                AfficheMenu(f)
            

def MenuFrmtr(f, fd):
    fd.pack_forget()
    fdr = Frame(f, padx=10, pady=10,bg="#DFDFDF")
    fdr.pack(padx=5, pady=5)
    md = Label(fdr, text="Bienvenue formateur", font="Tahoma 20", fg="#828282", width=30)
    md.grid(row=0, column=0, padx=5, pady=5, sticky=NW)



    # Define menu options
    optionsD = [
        "AAficher La liste des stagaires ",
        "Saisir notes",
        "Consulter les notes",
        "Deconnexion"
    ]
    n = 1
    for i in range(len(optionsD)):
        button = Button(fdr, text=optionsD[i], font="Arial 12", width=20)
        button.grid(row=n, column=i % 3 , padx=5, pady=5)
        if i % 3 == 2:
            n = n + 1
def MenuStag(f, fd):
    fd.pack_forget()
    fdr = Frame(f, padx=10, pady=10,bg="#DFDFDF")
    fdr.pack(padx=5, pady=5)
    md = Label(fdr, text="Bienvenue Stagiaire ", font="Tahoma 20", fg="#828282", width=30)
    md.grid(row=0, column=0, padx=5, pady=5, sticky=NW)

    # Define menu options
    optionsD = [
        "Consulter les notes",
        "Deconnexion"
    ]
    n = 1
    for i in range(len(optionsD)):
        button = Button(fdr, text=optionsD[i], font="Arial 12", width=20)
        button.grid(row=n, column=i % 3 , padx=5, pady=5)
        if i % 3 == 2:
            n = n + 1


def confirme(f, fd,x):
    if x=="Directeur":
        file="Directure.csv"
    elif x=="formateur":
        file="Formateur.csv"
    else :
        file="Stagiaire.csv"
    usser = euser.get()
    passe = epass.get()
    fo = open(file, 'r')
    csvr = csv.reader(fo)
    for line in csvr:
        if len(line) == 2:
            u, p = line
            if usser == u and passe == p and file=="Directure.csv":
                messagebox.showinfo("Confirmation", "Bienvenue Administrateur")
                MenuDrctr(f, fd)
            elif usser == u and passe == p and file=="Formateur.csv":
                messagebox.showinfo("Confirmation", "Bienvenue Formateur")
                MenuFrmtr(f, fd)
            elif usser == u and passe == p and file=="Stagiaire.csv":
                messagebox.showinfo("Confirmation", "Bienvenue Stagiaire")
                MenuStag(f, fd)
            else:
                 messagebox.showerror("Erreur", "Veuillez vérifier vos identifiants")
                 euser.delete(0, END)
                 epass.delete(0, END)
                 euser.focus()




def Operation(f, FM, x):
    FM.destroy()
    global fd
    fd = Frame(f, padx=5, pady=5, bg="#AFAFAF")
    if x == "Directeur":
        afficherFrameconnexion(f, fd, x)
    elif x== "formateur":
        afficherFrameconnexion(f, fd, x)
    else:
        afficherFrameconnexion(f, fd, x)

def OperationD(f, fdr, x):
    fdr.destroy()
    fdr2 = Frame(f, padx=5, pady=5, bg="#AFAFAF")
    if x == "Ajouter une filière":
        Framefilier(f, fdr2, x)
    elif x=="Ajouter un stagiaire":
        valideajouterstg(f, fdr2, x)
    elif x=="Déconnexion":
        AfficheMenu(f)


def valideajouterstg(f, fdr2, x):
    fdr2.pack(padx=5, pady=5)
    if List_Attend == []:
        messagebox.showinfo("Erreur", "La liste d'attente est vide")
    else:
        if len(ListStgr) <= 50:
            List_Attend.sort(key=getnote, reverse=True)
            for stg in List_Attend:
                fdr2.pack(padx=5, pady=5) 
                info_label =Label(fdr2, text=f"{stg.Nom} {stg.Prenom} {stg.BacNote}")
                info_label.pack(side=LEFT, padx=10)
                
                # Accept button
                accept_button = Button(fdr2, text="Accepter", command=lambda s=stg: accept_stagiaire(s))
                accept_button.pack(side=LEFT)
                
                # Reject button
                reject_button = Button(fdr2, text="Refuser", command=lambda s=stg: reject_stagiaire(s))
                reject_button.pack(side=LEFT)
                
            messagebox.showinfo("Confirmation", "Opération terminée.")
        else:
            messagebox.showinfo("Erreur", "La liste de stagiaires est insuffisante")

def accept_stagiaire(stg):
    ListStgr.append(stg)
    messagebox.showinfo("Confirmation", f"Vous avez accepté {stg.Nom} {stg.Prenom}")
    file = "AuthStagaires.csv"
    with open(file, 'a') as f:
        # Write CIN and password to the CSV file
        Pass = secrets.token_hex(5)
        f.write(f"{stg.CIN},{Pass}\n")
    List_Attend.remove(stg)
    
def reject_stagiaire(stg):
    messagebox.showinfo("Confirmation", f"Vous avez refusé {stg.Nom} {stg.Prenom}")
    List_Attend.remove(stg)
def Framefilier(f,fdr2,x):
    global fnom,Eabbr,module_1entry,module_2entry,module_3entry,coeff_1entry,coeff_2entry,coeff_3entry
    fdr2.pack(padx=5, pady=5)
    filier=Label(fdr2,text="Ajouter une filière:",font="Arial 18",fg="#807080",width=15)
    filier.grid(row=0,column=0,columnspan=2,padx=5,pady=5)
    lnom=Label(fdr2,text="NOM:",font="Arial 18",fg="#808080",width=15)
    lnom.grid(row=1,column=0,padx=5,pady=5)
    fnom=Entry(fdr2,font="Arial 18",state='normal')
    fnom.grid(row=1,column=1,padx=5,pady=5)
    labbr=Label(fdr2,text="Abréviation:",font="Arial 18",fg="#808080",width=15)
    labbr.grid(row=2,column=0,padx=5,pady=5)
    Eabbr=Entry(fdr2,font="Arial 18")
    Eabbr.grid(row=2,column=1,padx=5,pady=5)
     
    labbr=Label(fdr2,text="entree les modules:",font="Arial 18",fg="#808080",width=15)
    labbr.grid(row=3,column=0,padx=5,pady=5)
    module_1 = Label(fdr2, text="Module N°1:")
    module_1.grid(row=4, column=0, padx=5, pady=5)
    module_1entry = Entry(fdr2)
    module_1entry.grid(row=4, column=1, padx=5, pady=5)

    coeff_1 = Label(fdr2, text="Coefficient N°1:")
    coeff_1.grid(row=5, column=0, padx=5, pady=5)

    coeff_1entry = Entry(fdr2)
    coeff_1entry.grid(row=5, column=1, padx=5, pady=5)

    module_2 = Label(fdr2, text="Module N°2:")
    module_2.grid(row=6, column=0, padx=5, pady=5)
    module_2entry = Entry(fdr2)
    module_2entry.grid(row=6, column=1, padx=5, pady=5)
    coeff_2 = Label(fdr2, text="Coefficient N°2:")
    coeff_2.grid(row=7, column=0, padx=5, pady=5)
    coeff_2entry = Entry(fdr2)
    coeff_2entry.grid(row=7, column=1, padx=5, pady=5)


    module_3 = Label(fdr2, text="Module N°3:")
    module_3.grid(row=8, column=0, padx=5, pady=5)
    module_3entry = Entry(fdr2)
    module_3entry.grid(row=8, column=1, padx=5, pady=5)

    coeff_3 = Label(fdr2, text="Coefficient N°3:")
    coeff_3.grid(row=9, column=0, padx=5, pady=5)

    coeff_3entry = Entry(fdr2)
    coeff_3entry.grid(row=9, column=1, padx=5, pady=5)

    button_4 =Button(fdr2, text="ajouter", command=lambda:ajouterf(f,fdr2))
    button_4.grid(row=13,column=3,padx=5,pady=5)
    
# def handle_button_click(num_entries,fdr2):
#     global module_entry ,coeff_entry,module_entries, coeff_entries
#     module_entries, coeff_entries = [], []
#     n=5
#     for i in range(num_entries):
#         module_label = Label(fdr2, text=f"Module N°{i+1}:")
#         module_label.grid(row=n + 2*i, column=0, padx=5, pady=5)

#         module_entry = Entry(fdr2)
#         module_entry.grid(row=n + 2*i, column=1, padx=5, pady=5)
#         module_entries.append(module_entry)

#         coeff_label = Label(fdr2, text=f"Coefficient N°{i+1}:")
#         coeff_label.grid(row=n + 2*i + 1, column=0, padx=5, pady=5)

#         coeff_entry = Entry(fdr2)
#         coeff_entry.grid(row=n + 2*i + 1, column=1, padx=5, pady=5)
#         coeff_entries.append(coeff_entry)

def ajouterf(f, fdr2):
    nom = fnom.get()
    abbr = Eabbr.get()
    F = Filiere(nom, abbr)
    idFil = F.getid()
    listMods = []
    module_values = [module_1entry.get(), module_2entry.get(), module_3entry.get()]
    coeff_values = [int(coeff_1entry.get()), int(coeff_2entry.get()), int(coeff_3entry.get())]
    
    for i in range(3):
        mod = Module(module_values[i], idFil, coeff_values[i])
        listMods.append(mod)
        ToutsModules.append(mod)
        
    F.ListModules = listMods
    ListFiliere.append(F)  # Ensure that the list name is consistent
    
    messagebox.showinfo("info", "filier bien ajouter")
    for f in ListFiliere:
        print(f)
    for m in ToutsModules:
        print(m)
    fdr2.destroy()
    MenuDrctr(f, fd)

    

    


