from Classes import *
from Functions import *
from datetime import *

# S=Stagaire(123,"kamel","ismael",date(1998,8,23),"DD")
# # print(S)


dn=date(1998,8,23)
da=date(2016,8,23)

# print(int((da-dn).days/365.25))
file="Directure.csv"
User="admin"
Pass = "ista"

# if confirmeUtl(User,Pass,file):
#     print("Acces autorisé")
# else :
#     print("Acces non autorisé")

# MenuDrctr()
# MenuFrmtr()

def Inscription():
    print("Entrez votre date de naissance :")
    j=int(input("Jour :"))
    m=int(input("Mois :"))
    a=int(input("Année :"))
    DateNai=date(a,m,j)
    dateActu=date(2023,5,12)
    if VerifierAge(DateNai,dateActu)==False :
        return "vous ne peuvent pas iscrir !"
    else:
        print("Vous avez me Bac ? (Oui/Non) :", end="")
        rep=input().upper()
        if rep=="NON":
            print("Choisir une nouvaeu :")
            print(" \n 1 | Qualifaint \n 2 | Technicien")
            nov=int(input("Votre choix : "))
            if nov==1:
                print("Choisir une filiére :")
                print("\n 1 | Souduer \n 2 | Mecanique")
                fil=input("Votre choix : ")
            else :
                print("Choisir une filiére :")
                print(" \n 1 | Hotelier \n 2 | Dessin de Batiment",)
                fil=input("Votre choix : ")
        else :
            print("Choisir une nouvaeu :")
            print("\n 1 | Qualifaint \n 2 | Technicien \n 3 | Technicien Specialisé" )
            nov=int(input("Votre choix : "))
            if nov==1:
                print("Choisir une filiére :")
                print("\n 1 | Souduer \n 2 | Mecanique")
                fil=input("Votre choix : ")
            elif nov==2:
                print("Choisir une filiére :")
                print("\n 1 | Hotelier \n 2 | Dessin de Batiment")
                fil=input("Votre choix : ")
            else :
                print("Choisir une filiére :")
                print("\n 1 | DevDigital \n 2 | Gestion")
                fil=input("Votre choix : ")
    return f" Vous avez choisé {fil}" 


M1=Module("PHP",1,"PA122")
M2=Module("CSS",2,"PA457")
M3=Module("Python",2,"PA789")
M4=Module("HTML",1,"PA123")
LM=[M1,M2,M3,M4]
# print(Inscription())
DD=Filiere("Developpement Digital","DD",LM)
GE=Filiere("Gestion Des Entreprises","GE",LM)

F1=Formateur('P12345','Ait elka','Ismael',date(1998,8,23),LM)
F2=Formateur('P1234s5','Ait elka','Ismael',date(1998,8,23),LM)
LFO=[F1,F2]
# print(DD)
# print(GE)
ListFiliere=[DD,GE]
S1=Stagaire("PA2215",1,"Ait El Kamel","Ismael",date(1998,8,23),ListFiliere,11.66)
S2=Stagaire("PA2245",1,"Oudra","Brahim",date(1999,6,15),ListFiliere,11.58)
S3=Stagaire("PA2875",2,"Aassab","Hiba",date(2002,6,26),ListFiliere,14.74)
S4=Stagaire("PA2645",1,"Er-Rachedy","Yassine",date(2000,10,16),ListFiliere,14.98)
S5=Stagaire("PA2240",1,"Ait Lhassan","Ayoub",date(2004,8,20),ListFiliere,14.42)
# print(S)
# print(S2)
# LN=["SQL","JS","RUBY","JAVA"]
# print(LM + LN)
LA=[S1,S2,S3,S4,S5]
LS=[]
i=1
# afficherModules(LM)

# print("#########################")
# for mod in LM:
#     print("#",i,"|",spaceMenu(mod,17),"#")
#     i+=1
# print("#########################")
# LF=[]
# AfficherStagaire(LA)
# # AfficherFormateurs(LFO)
# SupremeFrmtr(LFO)
# for stg in LFO:
#     print(stg)
def RecupereNomFiliere():
    nomfiliere=[]
    for f in ListFiliere:
        nomfiliere.append(f.Nom)
    return nomfiliere
ValideFilier=RecupereNomFiliere()
print(ValideFilier)