DD=Filiere("Developpement Digital","DD",LM)
GE=Filiere("Gestion Des Entreprises","GE",LM)