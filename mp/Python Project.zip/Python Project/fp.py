from tkinter import *
from funcaffich import *

f = Tk()
f.title("Mini Projet Python")

l = Label(f, text="Gestion de scolarité", font="algerian 24", fg="blue", bg="#FCFCFC", width=100)
l.pack(padx=5, pady=5)
AfficheMenu(f)
f.mainloop()
